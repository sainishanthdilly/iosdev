//
//  Feed.swift
//  Homework2
//
//  Created by Sai Nishanth Dilly on 10/10/17.
//  Copyright © 2017 Shehab, Mohamed. All rights reserved.
//

import Foundation


class Feed{
    var releaseDate: String
    var price: String
    var squareImage: String
    var optionalImage : String?
    var summary : String?
    var title : String
    var name : String
    
    
    init() {
     self.title = ""
     self.name = ""
     self.price = ""
     self.releaseDate = ""
     self.squareImage = ""
        
        
    }
    
    
    
}
