//
//  PhotosCl.swift
//  InClass07
//
//  Created by Sai Nishanth Dilly on 10/26/17.
//  Copyright © 2017 Sai Nishanth Dilly. All rights reserved.
//

import Foundation


class PhotosCl{
var id : String
var imgURL : String
init(_ idU: String,iURL iurl : String){
    id = idU
    imgURL = iurl
}

}


